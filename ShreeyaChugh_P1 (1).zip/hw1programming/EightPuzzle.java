import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;



/*this is the class for eight puzzle */
class EightPuzzle {

    char[] currentStates = new char[9];
    char[] goalStates = new char[] { 'b', '1', '2', '3', '4', '5', '6', '7', '8' };
    int maxNodes = 15;
    int action;
    public String prevMove; 
     

    // this is a constructor for the eight puzzle class

    public EightPuzzle(char[] initial) {
        currentStates = initial;

    }
// this is a constructor for the eight puzzle class
    public EightPuzzle(){
        currentStates = new char[9];
    }
    
    public void filereading(String filepath) throws Exception {
        File file = new File(filepath);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String text;
        while ((text = br.readLine()) != null) {
            
            System.out.println(text.length());
            System.out.println(text.substring(0));
            //System.out.print(text.substring(0,2));
    if(text.substring(0, 8).equals("setState")){
                //System.out.println("Hi");
                String newState = text.substring(9, 12);
                newState += text.substring(13, 16);
                newState += text.substring(17, 20);
        
                setState(newState);
                System.out.println("The state has been set");
      
            } else if (text.substring(0, 4).equals("move")) {
                //System.out.println("Hi2");
                move(text.substring(5));
                System.out.println("b, or the blank tile has been moved");
            } else if (text.substring(0, 10).equals("printState")) {
                //System.out.println("Hi 3");
                printState();   
                System.out.println("The current state has been printed");
            } else if (text.substring(0, 8).equals("maxNodes")) {
                //System.out.println("Hi 4"); 
                maxNodes(Integer.parseInt(text.substring(9,11)));
                System.out.println("maxNode was changed to  "+ maxNodes);
            } else if (text.substring(0, 10).equals("solveAStar")) {
                //System.out.println("Hi 5");
                System.out.println("A* begins here");
                String heuristic = text.substring(11, 13);
                solveAStar(heuristic);
               
                System.out.println("A* has terminated");
            } else if (text.substring(6, 11).equals("local")) {
                System.out.println(text.substring(17, 19));
                String k = text.substring(17,19);
                solve_local_beam(Integer.parseInt(k));
                System.out.println("Local beam search has terminated");
            }
            
        }
        br.close();
    }

// the setState() method takes a string input and uses that to set the state
    public void setState(String string_state) {
        // removing the empty spaces
        string_state = string_state.replaceAll("\\s", "");
        for (int i = 0; i < 9; i++) {
            currentStates[i] = string_state.charAt(i);
        }

    }

   
// this method prints the state in the format "*** *** ***"
    public void printState() {

        for (int i = 0; i < 3; i++) {
            System.out.print(currentStates[i]);
        }

        System.out.print(" ");

        for (int i = 3; i < 6; i++) {
            System.out.print(currentStates[i]);
        }

        System.out.print(" ");
        for (int i = 6; i < 9; i++) {
            System.out.print(currentStates[i]);
        }
        System.out.println(" ");

    }
   // moves the blank tile in the direction specified by the input
    public boolean move(String direction) {
        int b_index = this.getIndB();
        boolean res = false;
        if (direction.equals("up") && b_index > 2) {
            exchange(b_index, b_index - 3);
            res = true;
        } else if (direction.equals("down") && b_index < 6) {
            exchange(b_index, b_index + 3);
            res = true;
        } else if (direction.equals("left") && b_index != 0 && b_index != 3 && b_index != 6) {
            exchange(b_index, b_index - 1);
            res = true;
        } else if (direction.equals("right") && b_index != 2 && b_index != 5 && b_index != 8) {
            exchange(b_index, b_index + 1);
            res = true;
        }
        return res;
    }
// exchanges two elements in currentStates
    public void exchange(int p, int q) {
        char temp = currentStates[p];
        currentStates[p] = currentStates[q];
        currentStates[q] = temp;

    }
// gets the index of the blank tile 
    public int getIndB() {
        int ind = -1;
        for (int i = 0; i < currentStates.length; i++) {
            if (currentStates[i] == 'b') {
                ind = i;
                break; 
            }
        }
        if (ind < 0 || ind >= currentStates.length) {
            throw new IndexOutOfBoundsException("this index is out of bounds");
        }
        return ind;
    }
// randomizes state
    public void randomizeState(int num_moves) {
        this.setState("b12 345 678");
        if (num_moves < 0) {
            throw new IllegalArgumentException("the number of moves cannot be less than 0");
        }
        String[] possible_moves = { "up", "down", "left", "right" };
        String random_move;
        for (int i = 0; i < num_moves; i++) {
            random_move = possible_moves[(int) (4 * Math.random())];
            move(random_move);
        }

    }
 // sets n to be the maxNodes
    public void maxNodes(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("n must be at least one. Try again.");
        } else {
            maxNodes = n;
        }
    }
/* method uses A* algorithm to reach the goal state
if heuristic is h1, then it finds the number of misplaced tiles as heuristic
if heuristic is h2, then it finds the manhattan distance and uses that as heuristic
*/ 
    public void solveAStar(String heuristic) {
        if (heuristic.equals("h1")) {
            solve_misplaced_tiles();

        } else if (heuristic.equals("h2")) {
            solve_manhattan();
        }

    }
// this is a helper method for solveAStar
    public void solve_misplaced_tiles() {
        // keeping track of visited states
        ArrayList<EightPuzzle> visitedStates = new ArrayList<EightPuzzle>();
        // storing values of heuristic function
        ArrayList<Integer> queue_vals = new ArrayList<Integer>();
        printState();
        int solutionLength = 0;
        EightPuzzle x = new EightPuzzle();
        for(int i=0; i<9;i++){
            x.currentStates[i] = currentStates[i];
        }
        visitedStates.add(x);
        queue_vals.add(get_num_misplaced(x.currentStates));
        while (Arrays.equals(this.currentStates, x.goalStates)==false && solutionLength < maxNodes) {
            visitedStates.remove(0);
            queue_vals.remove(0);
            
            solutionLength++;

            EightPuzzle exploreUp = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreDown = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreLeft = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreRight = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            if (exploreUp.move("up")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreUp.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreUp.currentStates, exploreUp.currentStates.length));
                    nextState.action = 1;
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength + get_num_misplaced(exploreUp.currentStates));
                    
                }
            }
            if (exploreDown.move("down")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreDown.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreDown.currentStates, exploreDown.currentStates.length));
                    nextState.action = 2; // set action to 2 for moving down
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength + get_num_misplaced(exploreDown.currentStates));
                    
                }
            }
            if (exploreLeft.move("left")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreLeft.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreLeft.currentStates, exploreLeft.currentStates.length));
                    nextState.action = 3; // set action to 3 for moving left
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength+ get_num_misplaced(exploreLeft.currentStates));
                   
                }
            }
            if (exploreRight.move("right")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreRight.currentStates)) {
                        contain = true;
                       break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreRight.currentStates, exploreRight.currentStates.length));
                    nextState.action = 4; // set action to 4 for moving right
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength + get_num_misplaced(exploreRight.currentStates));
                    
                }
            }
            // sorts the states based on heuristic value
            for(int i = visitedStates.size()-1; i>=0; i--){
                for(int j = 1; j<=i; j++){
                    if(queue_vals.get(j-1) > queue_vals.get(j)){
                        int val1 = queue_vals.get(j-1);
                        queue_vals.set(j-1,queue_vals.get(j));
                        queue_vals.set(j, val1);
                        EightPuzzle temp2 = new EightPuzzle();
                        temp2 = visitedStates.get(j-1);
                        visitedStates.set(j-1, visitedStates.get(j));
                        visitedStates.set(j, temp2);
                    }
                    
                }
                
                
            }
           
            
            for(int i=0; i<9; i++){
                this.currentStates[i] = visitedStates.get(0).currentStates[i];
            }
            int action  = visitedStates.get(0).action;
            printState();
            switch (action) {
                case 1:
                    System.out.println("Moved up");
                    printState();
                    break;
                case 2:
                    System.out.println("Moved down");
                    printState();
                    break;
                case 3:
                    System.out.println("Moved left");
                    printState();
                    break;
                case 4:
                    System.out.println("Moved right");
                    printState();
                    break;
            }
   
        }

        if(Arrays.equals(this.currentStates, x.goalStates)){
            System.out.println("Solution found: ");
            printState();
        }

}
    
// returns the number of misplaced tiles, helper for solveAStar
    public int get_num_misplaced(char[] state_string) {
        int misplaced_tiles = 0;
        for (int i = 0; i < 9; i++) {
            if (state_string[i] != this.goalStates[i] && state_string[i] != 'b')
                misplaced_tiles++;
        }
        return misplaced_tiles;
    }
// helper for solveAStar
    public void solve_manhattan() {
        ArrayList<EightPuzzle> visitedStates = new ArrayList<EightPuzzle>();
        ArrayList<Integer> queue_vals = new ArrayList<Integer>();
        printState();
        int solutionLength = 0;
        EightPuzzle puzzle = new EightPuzzle();
        for(int i=0; i<9;i++){
            puzzle.currentStates[i] = currentStates[i];
        }
        visitedStates.add(puzzle);
        queue_vals.add(manhattan_helper(puzzle.currentStates));
        while (Arrays.equals(this.currentStates, puzzle.goalStates)==false && solutionLength < maxNodes) {
            visitedStates.remove(0);
            queue_vals.remove(0);
           
            solutionLength++;

            EightPuzzle exploreUp = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreDown = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreLeft = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            EightPuzzle exploreRight = new EightPuzzle(Arrays.copyOf(currentStates, currentStates.length));
            if (exploreUp.move("up")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreUp.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreUp.currentStates, exploreUp.currentStates.length));
                    nextState.action = 1;
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength+ manhattan_helper(exploreUp.currentStates));
                    
                }
            }
            if (exploreDown.move("down")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreDown.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreDown.currentStates, exploreDown.currentStates.length));
                    nextState.action = 2; // set action to 2 for moving down
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength + manhattan_helper(exploreDown.currentStates));
                    
                }
            }
            if (exploreLeft.move("left")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreLeft.currentStates)) {
                        contain = true;
                        break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreLeft.currentStates, exploreLeft.currentStates.length));
                    nextState.action = 3; // set action to 3 for moving left
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength + manhattan_helper(exploreLeft.currentStates));
                   
                }
            }
            if (exploreRight.move("right")) {
                boolean contain = false;
                for (int i = 0; i < visitedStates.size(); i++) {
                    if (Arrays.equals(visitedStates.get(i).currentStates, exploreRight.currentStates)) {
                        contain = true;
                       break;
                    }
                }
                if (!contain) {
                    EightPuzzle nextState = new EightPuzzle(
                            Arrays.copyOf(exploreRight.currentStates, exploreRight.currentStates.length));
                    nextState.action = 4; // set action to 4 for moving right
                    visitedStates.add(nextState);
                    queue_vals.add(solutionLength+manhattan_helper(exploreRight.currentStates));
                    
                }
            }
            for(int i = visitedStates.size()-1; i>=0; i--){
                for(int j = 1; j<=i; j++){
                    if(queue_vals.get(j-1) > queue_vals.get(j)){
                        int val1 = queue_vals.get(j-1);
                        queue_vals.set(j-1,queue_vals.get(j));
                        queue_vals.set(j, val1);
                        EightPuzzle temp2 = new EightPuzzle();
                        temp2 = visitedStates.get(j-1);
                        visitedStates.set(j-1, visitedStates.get(j));
                        visitedStates.set(j, temp2);
                    }
                }
            }
            
            
            for(int i=0; i<9; i++){
                this.currentStates[i] = visitedStates.get(0).currentStates[i];
            }
            int action  = visitedStates.get(0).action;
            printState();
            // prints out the actions that were taken
            switch (action) {
                case 1:
                    System.out.println("Moved up");
                    printState();
                    break;
                case 2:
                    System.out.println("Moved down");
                    printState();
                    break;
                case 3:
                    System.out.println("Moved left");
                    printState();
                    break;
                case 4:
                    System.out.println("Moved right");
                    printState();
                    break;
            }
   
        }

        if(Arrays.equals(this.currentStates, puzzle.goalStates)){
            System.out.println("Solution found: ");
            printState();
        }
        
        }
    
// helper method that finds manhattan distance
    public int manhattan_helper(char[] state_string) 
    {
        int[] number = new int[9]; // convert char[] to int[]
        int distance = 0;
        for (int ind = 0; ind < 9; ind++) {
            if (state_string[ind] != 'b')
                number[ind] = Character.getNumericValue(state_string[ind]);
            else
                number[ind] = 0;
        }
// calculates the absolute differnces between the x and y coordinate
        int index = -1;
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                index++;
                if (number[index] != 0) {
                    // calculates for horizontal and vertical directions
                    int horizontal = number[index] % 3;
                    int vertical = number[index] / 3;
                    distance += Math.abs(vertical - (y)) + Math.abs(horizontal - (x));
                }
            }
        }
        return distance;
    }
  // finds random state from current state
    public void random_from_current(int moves) {
        Random r = new Random(); 
        r.setSeed(10);
        int i = 0;
        while (i < moves) {
            boolean done = false;
            int direction = r.nextInt(4);
            if (direction == 0) {
                done = move("up");
            }
            if (direction == 1) {
                done = move("down");
            }
            if (direction == 2) {
               done = move("right");
            }
            if (direction == 3) {
                done = move("left");
            }
            if (done == true) {
                i = i + 1;
            } else {
                ;
            }
            
        }
    }

// uses local beam search to convert current state to goal state
public void solve_local_beam(int k) {
    ArrayList<EightPuzzle> solution = new ArrayList<>();
    ArrayList<EightPuzzle> intermediates = new ArrayList<>();
    int generated = 0;
    
    for (int b = 0; b < 100; b++) {
        if (generated < k) {
            EightPuzzle y = new EightPuzzle();
            for (int a = 0; a < 9; a++) {
                y.currentStates[a] = this.currentStates[a];
            }
            y.random_from_current(1);
            boolean contain = false;
            for (int i = 0; i < solution.size(); i++) {
                if (Arrays.equals(solution.get(i).currentStates, y.currentStates)) {
                    contain = true;
                }
            }
            if (!contain) {
                solution.add(y);
                generated++;
                y.prevMove = "Initial";
               
            }
        }
    }
    boolean finished = false;
    int r = 0;
    while (!finished && r < maxNodes) {
        r++;
        
        for (int a = 0; a < solution.size(); a++) {
            ArrayList<EightPuzzle> x = get_intermediate(solution.get(a), solution.get(a).prevMove);
            for (int b = 0; b < x.size(); b++) {
                intermediates.add(x.get(b));
            }
        }
        ArrayList<EightPuzzle> selected_intermediates = new ArrayList<>();
        for (int c = 0; c < intermediates.size(); c++) {
            if (Arrays.equals(intermediates.get(c).currentStates, goalStates)) {
                finished = true;
                this.currentStates = intermediates.get(c).currentStates;
                intermediates.get(c).printState();
            }
        }
        if (!finished) {
            ArrayList<Integer> value = new ArrayList<>();
            for (int h = 0; h < intermediates.size(); h++) {
                value.add(manhattan_helper(intermediates.get(h).currentStates));
            }
            for (int z = intermediates.size() - 1; z >= 0; z--) {
                for (int p = 1; p <= z; p++) {
                    if (value.get(p - 1) > value.get(p)) {
                        int val1 = value.get(p - 1);
                        value.set(p - 1, value.get(p));
                        value.set(p, val1);
                        EightPuzzle temp2 = intermediates.get(p - 1);
                        intermediates.set(p - 1, intermediates.get(p));
                        intermediates.set(p, temp2);
                    }
                }
            }
            for (int d = 0; d < Math.min(k-1, intermediates.size()); d++) {
                selected_intermediates.add(intermediates.get(d));
            }
            solution.clear();
            for (int m = 0; m < selected_intermediates.size(); m++) {
                solution.add(selected_intermediates.get(m));
            }
            selected_intermediates.clear();
            for (int q = 0; q < solution.size(); q++) {
                System.out.println(solution.get(q).prevMove);
                solution.get(q).printState();
            }
        }
    }
}
// gets the intermediate states
  
public ArrayList<EightPuzzle> get_intermediate(EightPuzzle state_string, String prevMove) {
    ArrayList<EightPuzzle> intermediate = new ArrayList<EightPuzzle>();
    EightPuzzle exploreUp = new EightPuzzle();
    for (int i = 0; i < 9; i++) {
        exploreUp.currentStates[i] = state_string.currentStates[i];
    }
    EightPuzzle exploreDown = new EightPuzzle();
    for (int i = 0; i < 9; i++) {
        exploreDown.currentStates[i] = state_string.currentStates[i];
    }
    EightPuzzle exploreLeft = new EightPuzzle();
    for (int i = 0; i < 9; i++) {
        exploreLeft.currentStates[i] = state_string.currentStates[i];
    }
    EightPuzzle exploreRight = new EightPuzzle();
    for (int i = 0; i < 9; i++) {
        exploreRight.currentStates[i] = state_string.currentStates[i];
    }
    if (exploreUp.move("up")) {
        exploreUp.prevMove = prevMove + ", Moving up";
        intermediate.add(exploreUp);
    }
    if (exploreDown.move("down")) {
        exploreDown.prevMove = prevMove + ", Moving down";
        intermediate.add(exploreDown);
    }
    if (exploreLeft.move("left")) {
        exploreLeft.prevMove = prevMove + ", Moving left";
        intermediate.add(exploreLeft);
    }
    if (exploreRight.move("right")) {
        exploreRight.prevMove = prevMove + ", Moving right";
        intermediate.add(exploreRight);
    }
    return intermediate;
}

    // finds the number of inversions to see if state is solvable or not
public String isSolvable() {
    Collections.shuffle(Arrays.asList(currentStates));
    
    int inversions = 0;
    for (int i = 0; i < 8; i++) {
        for (int j = i+1; j < 9; j++) {
            if (currentStates[i] > 0 && currentStates[j] > 0 && currentStates[i] > currentStates[j]) {
                inversions++;
            }
        }
    }
   if (inversions % 2 == 0){
   return "solvable";
   
   }
   else{
    
    return "unsolvable";
   }
}

public String return_random_state(){
    return ("b" + (Math.random()*8 + 1)).toString();
}

// experiment 1
public void experiment(){
    int solvable = 0;
    int unsolvable = 0;
    EightPuzzle a = new EightPuzzle(currentStates);
    for(int i = 0; i < 100; i++){
    
    a.setState(a.return_random_state());
       if (a.isSolvable().equals("solvable")){
       solvable++;
       }
       else{
        unsolvable++;
       }
    }
    System.out.println(solvable );
    System.out.println(unsolvable );
    
}



    // this is the main method for testing

    public static void main(String[] args) throws Exception {

     
        
        char[] arr = new char[] { 'b', '1', '2', '3', '4', '5', '6', '7', '8' };
        EightPuzzle b = new EightPuzzle(arr);
        b.filereading("/Users/shreeyachugh/Desktop/test.txt");
    }
}
        /* 
        b.setState("1b2 345 678");
        b.solveAStar("h2");
        System.out.println("solution found");
        
        b.setState("12b 345 678");
        b.solveAStar("h2");
        System.out.println("solution found");
        b.setState("b12 345 678");
        b.solveAStar("h1");
        System.out.println("solution found");
        b.setState("312 b45 678");
        b.solveAStar("h1");
        b.setState("312 4b5 678");
        b.solveAStar("h1");
        
        
        EightPuzzle a = new EightPuzzle(arr);
        

        a.setState("312 45b 678");
        b.solve_local_beam(10);
        b.setState("712 456 6b8");
        
        
        
       
        
        
         
         
         // run time calculations
         System.out.println(a.isSolvable());
         long startastar = System.nanoTime();
         a.solveAStar("h1");
         long endastar = System.nanoTime();
         long astartime = endastar-startastar;
         System.out.println("the total time it took for h1 is" + astartime +
          " nanoseconds");
         
        
         long startastarh2 = System.nanoTime();
         a.solveAStar("h2");
         long endastarh2 = System.nanoTime();
         long astartimeh2= endastarh2-startastarh2;
         System.out.println("the total time it took for h2 is " + astartimeh2+
         " nanoseconds");
         long startbeam1 = System.nanoTime();
         a.solve_local_beam(2);
         long endbeam1 = System.nanoTime();
         long beam1time= endbeam1-startbeam1;
         System.out.println("the total time it took for local beam is " + beam1time +
         " nanoseconds");
          long startbeam2= System.nanoTime();
         a.solve_local_beam(20);
         long endbeam2 = System.nanoTime();
         long beam2time= endbeam2-startbeam2;
         System.out.println("the total time it took for local beam with k = 20 is " +
         beam2time + " nanoseconds");
         

      */
      
        



